#include "hero.h"
#include "arrow.h"
#include "healpotion.h"
//#include "Directions.h"

Hero::Hero() : Creature(50, 0, 5)
{

}

void Hero::keyPressEvent(QKeyEvent *event)
{
    QList<QGraphicsItem *> collidingItemsList = collidingItems();
    for (int i = 0, n = collidingItemsList.size(); i < n; ++i ) {
        if (typeid (*(collidingItemsList.at(i))) == typeid(HealPotion)) {
            HealPotion * orc = (HealPotion *)collidingItemsList.at(i);
//            int newHP = orc->getHP() - 5;
                scene()->removeItem(collidingItemsList.at(i));
                delete collidingItemsList.at(i);
                this->addHealPotion();
                qDebug() << this->HealPotionsCount();
        }
    }
//    qDebug() << "some key is pressed from hero";
    if (event->key() == Qt::Key_Left) {
        if (x() > 0)
            setPos(x() - 10, y());
        curDirection = Left;
    } else if (event->key() == Qt::Key_Right) {
        if (x() < scene()->width())
            setPos(x() + 10, y());
        curDirection = Right;
    } else if (event->key() == Qt::Key_Up) {
        if (y() > 0)
            setPos(x(), y() - 10);
        curDirection = Up;
    } else if (event->key() == Qt::Key_Down) {
        if (y() < scene()->height())
            setPos(x(), y() + 10);
        curDirection = Down;
    } else if (event->key() == Qt::Key_E) {
        Arrow * arrow = new Arrow(curDirection);
        arrow->setPos(x(), y());
        scene()->addItem(arrow);
//        arrow->setSceneSize(scene()->sceneRect().width(), scene()->sceneRect().height());
    }
}




