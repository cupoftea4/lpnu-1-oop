#ifndef GAMEVIEW_H
#define GAMEVIEW_H

#include <QGraphicsView>
#include <QGraphicsScene>

class GameView : public QGraphicsView
{
public:
    GameView();
    void setViewSize(int w, int h) {viewW = w; viewH = h;}
    int ViewW() { return viewW; }
    int ViewH() { return viewH; }

private:
    void showEvent( QShowEvent* event );
    int viewW;
    int viewH;
};

#endif // GAMEVIEW_H
