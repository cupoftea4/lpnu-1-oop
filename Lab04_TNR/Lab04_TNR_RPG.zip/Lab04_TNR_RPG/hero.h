#ifndef HERO_H
#define HERO_H

#include <QWidget>
#include <QPoint>
#include <QKeyEvent>
#include <QGraphicsScene>
#include "creature.h"
#include "Directions.h"

class Hero : public Creature
{
public:
    Hero();
    void keyPressEvent(QKeyEvent * event);
    void addHealPotion() { healPotionsCount++; }
    int HealPotionsCount() { return healPotionsCount; }
private:
    int healPotionsCount = 0;

    Directions curDirection;
};

#endif // HERO_H
