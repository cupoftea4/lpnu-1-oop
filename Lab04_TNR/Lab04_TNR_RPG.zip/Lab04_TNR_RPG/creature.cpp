#include "creature.h"

Creature::Creature()
{

}

Creature::Creature(int HP, int gold, int damage)
{
    this->HP = HP;
    this->gold = gold;
    this->damage = damage;

}

//void Creature::keyPressEventC(QKeyEvent *event)
//{
//     qDebug() << "some key is pressed from creature";
//}

