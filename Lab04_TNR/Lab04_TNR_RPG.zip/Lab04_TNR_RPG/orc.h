#ifndef ORC_H
#define ORC_H

#include "creature.h"

class Orc: public Creature
{
public:
    Orc(int lvl);
    void setPosition(int x, int y) { this->x = x; this->y = y; }
    int X() { return x; }
    int Y() { return y; }

private:
    int level;
    int x;
    int y;

};

#endif // ORC_H
