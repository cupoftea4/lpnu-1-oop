#include "healpotionspawner.h"

HealPotionSpawner::HealPotionSpawner()
{
    SpawnHealPotions(5);
}

void HealPotionSpawner::SpawnHealPotions(int count)
{
    for(int i = 0; i < count; i++) {
        HealPotion * potion = new HealPotion();
        potion->setPos(rand()%1000+100, rand()%700+100);
        healPotions.append(potion);
    }
}
