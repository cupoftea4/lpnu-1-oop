#include "orcspawner.h"

OrcSpawner::OrcSpawner()
{
    spawnOrcs(1, 4);
}

void OrcSpawner::spawnOrcs(int lvl, int quantity)
{
    for(int i = 0; i < quantity; i++) {
        Orc * orc = new Orc(lvl);
        orc->setPos(rand()%700, rand()%700);
        orcs.append(orc);
    }
}
