#include "arrow.h"
#include <QList>
#include "orc.h"

Arrow::Arrow(Directions dir)
{
    direction = dir;
    QTimer * timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &Arrow::move);
    timer->start(50);
//    sceneH = scene()->height();
//    sceneW = scene()->width();
}

void Arrow::move() {
//    qDebug() << "move...";
    QList<QGraphicsItem *> collidingItemsList = collidingItems();
    for (int i = 0, n = collidingItemsList.size(); i < n; ++i ) {
        if (typeid (*(collidingItemsList.at(i))) == typeid(Orc)) {
            Orc * orc = (Orc *)collidingItemsList.at(i);
            int newHP = orc->getHP() - 5;
            qDebug() << newHP;
            if (newHP <= 0) {
                scene()->removeItem(collidingItemsList.at(i));
                delete collidingItemsList.at(i);
            } else {
                orc->setHP(newHP);
            }
            scene()->removeItem(this);
            delete this;
            return;
        }
    }

    if (direction == Left) {
        setPos(x()-10, y());
    } else if (direction == Right) {
        setPos(x()+10, y());
    } else if (direction == Up) {
        setPos(x(), y()-10);
    } else if (direction == Down) {
        setPos(x(), y()+10);
    }
    if (y() < 0 || x() < 0 || x() > scene()->width() || y() > scene()->height()) {
        scene()->removeItem(this);
        delete this;
        qDebug() << "deleted";
    }
}

