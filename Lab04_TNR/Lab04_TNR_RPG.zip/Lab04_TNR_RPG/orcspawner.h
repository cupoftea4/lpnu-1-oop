#ifndef ORCSPAWNER_H
#define ORCSPAWNER_H
#include <QList>
#include <orc.h>
#include <QGraphicsScene>

class OrcSpawner
{
public:
    OrcSpawner();
    QList<Orc *> orcs;
private:
    void spawnOrcs(int lvl, int quantity);
};

#endif // ORCSPAWNER_H
