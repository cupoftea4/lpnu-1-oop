#ifndef DIRECTIONS_H
#define DIRECTIONS_H

#include <QScreen>
#include <QRect>
#include <QGuiApplication>

enum Directions {
    Left,
    Right,
    Up,
    Down
};

//QScreen *screen = QGuiApplication::primaryScreen();
//QRect  screenGeometry = screen->geometry();
//extern int screenHeight = screenGeometry.height();
//extern int screenWidth = screenGeometry.width();

#endif // DIRECTIONS_H
