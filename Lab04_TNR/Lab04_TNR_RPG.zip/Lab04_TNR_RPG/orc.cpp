#include "orc.h"

Orc::Orc(int lvl): Creature()
{
    setHP(lvl*10);
    setDamage(lvl*5);
    setGold(lvl*10);
    level = lvl;
}

