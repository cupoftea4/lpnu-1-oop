#include "gameview.h"
#include <QDebug>
#include <QApplication>

GameView::GameView()
{

}

void GameView::showEvent( QShowEvent* event ) {
    QWidget::showEvent( event );
//    viewW = 4;
//    viewH = QGraphicsView::size().height();
//    qDebug() << viewH << " " << viewW;
//    this->scene()->setSceneRect(0, 0, QGraphicsView::size().width(), QGraphicsView::size().height());
}


