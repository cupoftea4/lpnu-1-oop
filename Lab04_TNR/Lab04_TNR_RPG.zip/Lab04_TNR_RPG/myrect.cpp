#include "myrect.h"
#include <QDebug>

//MyRect::MyRect()
//{

//}

//void MyRect::keyPressEvent(QKeyEvent *event)
//{
//    qDebug() << "jdjsj";
//}

void MyRect::onKeyPressed(QKeyEvent *event)
{
    qDebug() << "some key pressed";
}
