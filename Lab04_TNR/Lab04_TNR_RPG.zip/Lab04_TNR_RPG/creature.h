#ifndef CREATURE_H
#define CREATURE_H

#include <QGraphicsItem>
#include <QPainter>

class Creature : public QGraphicsItem
{
public:
    Creature();
    Creature(int HP, int gold, int damage);
//    ~Creature();
    int getHP() {
        return HP;
    }
    void setHP(int newHP) {
        if(newHP >= 0 && newHP <= 50) HP = newHP;
    }
    int getGold() {
        return gold;
    }
    void setGold(int newGold) {
        if(newGold >= 0 && newGold <= 100) gold = newGold;
    }
    int getDamage() {
        return damage;
    }
    void setDamage(int newDamage) {
        if(newDamage >= 0 && newDamage <= 10) damage = newDamage;
    }
    static void setSceneSize(int w, int h) { sceneW = w; sceneH = h; }
    static int SceneW() { return sceneW; }
    static int SceneH() { return sceneH; }

private:
    int HP = 0;
    int gold = 0;
    int damage = 0;
    static int sceneW;
    static int sceneH;
//    void keyPressEventC(QKeyEvent * event);
    QRectF boundingRect() const override
    {
        qreal penWidth = 1;
        return QRectF(-10 - penWidth / 2, -10 - penWidth / 2,
                      20 + penWidth, 20 + penWidth);
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
               QWidget *widget) override
    {
        painter->drawRoundedRect(-10, -10, 20, 20, 5, 5);
//        painter->drawRoundedRect()
    }

};

#endif // CREATURE_H
