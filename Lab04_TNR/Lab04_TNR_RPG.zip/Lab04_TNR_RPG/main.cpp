#include "game.h"
#include "creature.h"
#include "hero.h"
//#include "Directions.h"

#include <QApplication>
#include <QGraphicsScene>
#include "gameview.h"
#include "arrow.h"
#include "orcspawner.h"
#include "healpotionspawner.h"


/*
 To do:
    - scene size(arrow behind scene)
    - arrow range 300px
*/

int main(int argc, char *argv[])
{
//    HealPotion * heal = new HealPotion();
    QApplication a(argc, argv);
    QSplashScreen *splash= new QSplashScreen( QPixmap("loadingScreen.jpg"), Qt::WindowStaysOnTopHint);
    splash->show();

    QGraphicsScene * scene = new QGraphicsScene();
    Hero * hero = new Hero();
    scene->addItem(hero);

    hero->setFlag(QGraphicsItem::ItemIsFocusable);
    hero->setFocus();

    GameView * view = new GameView();
    view->setScene(scene);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setWindowState(Qt::WindowMaximized);

    QScreen *screen = QGuiApplication::primaryScreen();
    QRect  screenGeometry = screen->geometry();
    int height = screenGeometry.height();
    int width = screenGeometry.width();

//    qDebug() << height << " " << width;
    scene->setSceneRect(0, 0, width, height);

    OrcSpawner * orcSpawner = new OrcSpawner();
    int orcsCount = orcSpawner->orcs.size();
    for (int i = 0; i < orcsCount; i++) {
        scene->addItem(orcSpawner->orcs.at(i));
    }

    HealPotionSpawner * potSpawner = new HealPotionSpawner();
    int potCount = potSpawner->healPotions.size();
    for (int i = 0; i < potCount; i++) {
        scene->addItem(potSpawner->healPotions.at(i));
    }

    //    Game w;
    QTimer::singleShot(4000, splash, SLOT(close()));
    QTimer::singleShot(4000, view, SLOT(show()));
//    QTimer::singleShot(4000, scene, SLOT());
    return a.exec();
}
