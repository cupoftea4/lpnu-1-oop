#include "healpotion.h"

HealPotion::HealPotion()
{

}

void HealPotion::AddPotion()
{

}
